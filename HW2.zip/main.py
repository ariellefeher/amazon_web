import requests
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from datetime import datetime, timedelta
from bs4 import BeautifulSoup

app = FastAPI()

# Enable CORS to allow cross-origin requests
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Search results data
search_results = []

# Past searches data
past_searches = []

# Maximum number of searches per day per user
max_searches_per_day = 10

# User search count tracker
user_search_counts = {}

# Middleware to track user search counts
@app.middleware("http")
async def track_user_search_counts(request, call_next):
    now = datetime.now().date().isoformat()
    if request.url.path == "/search" and request.method == "POST":
        ip = request.client.host
        if ip not in user_search_counts:
            user_search_counts[ip] = {now: 0}
        elif now not in user_search_counts[ip]:
            user_search_counts[ip][now] = 0
        user_search_counts[ip][now] += 1

        # Check if user has exceeded the maximum number of searches per day
        if user_search_counts[ip][now] > max_searches_per_day:
            return JSONResponse(content={"error": "Search limit exceeded for today"}, status_code=429)

    response = await call_next(request)
    return response

# Search endpoint
@app.post("/search")
async def search(query: str):
    # Make request to Amazon.com search page with the given query
    search_temp = "winter jacket"
    url = f"https://www.amazon.com/s?k={query}"
    response = requests.get(url)

    # Parse the HTML response
    soup = BeautifulSoup(response.text, "html.parser")

    # Extract the top 10 product titles, ratings, and ASINs
    results = soup.find_all("div", {"data-index": True})
    search_results = []
    for result in results[:10]:  # Limit to top 10 results
        title_element = result.find("span", {"class": "a-size-medium a-color-base a-text-normal"})
        rating_element = result.find("span", {"class": "a-icon-alt"})
        asin_element = result["data-asin"]
        if title_element and rating_element and asin_element:
            title = title_element.text
            rating = float(rating_element.text.split()[0])
            asin = asin_element
            search_results.append({"title": title, "rating": rating, "asin": asin})

    # Return search results as JSON response
    return JSONResponse(content=search_results)


# Price comparison endpoint
@app.get("/price/{asin}")
async def price(asin: str):
    # Make request to Amazon.com product page with the given ASIN
    url = f"https://www.amazon.com/dp/{asin}"
    response = requests.get(url)

    # Parse the HTML response
    soup = BeautifulSoup(response.text, "html.parser")

    # Extract the item's name, price, and rating from Amazon.com
    name_element = soup.find("span", {"id": "productTitle"})
    price_element = soup.find("span", {"class": "a-price-whole"})
    rating_element = soup.find("span", {"class": "a-icon-alt"})

    # Extract the name, price, and rating values if available, otherwise set them to None
    item_name = name_element.text.strip() if name_element else None
    item_price = float(price_element.text.replace(",", "")) if price_element else None
    item_rating = float(rating_element.text.split()[0]) if rating_element else None

    # Extract prices from Amazon.co.uk, Amazon.de, and Amazon.ca
    prices = {}
    amazon_uk_element = soup.find("span", {"class": "a-price-whole", "data-price-id": "1"})
    amazon_de_element = soup.find("span", {"class": "a-price-whole", "data-price-id": "2"})
    amazon_ca_element = soup.find("span", {"class": "a-price-whole", "data-price-id": "3"})
    prices["Amazon.com"] = item_price
    prices["Amazon.co.uk"] = float(amazon_uk_element.text.replace(",", "")) if amazon_uk_element else None
    prices["Amazon.de"] = float(amazon_de_element.text.replace(",", "")) if amazon_de_element else None
    prices["Amazon.ca"] = float(amazon_ca_element.text.replace(",", "")) if amazon_ca_element else None

    # Return item name, rating, and prices as JSON response
    return JSONResponse(content={"Item": item_name, "Rating": item_rating, "Amazon.com": item_price, "Amazon.co.uk": prices["Amazon.co.uk"], "Amazon.de": prices["Amazon.de"], "Amazon.ca": prices["Amazon.ca"]})
